import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
import seaborn as sns
import matplotlib.pyplot as plt
import nltk
import string
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from wordcloud import WordCloud
from collections import Counter


# Read the CSV file with the specified encoding
df = pd.read_csv('spam.csv', encoding='ISO-8859-1')

# Drop unnecessary columns
df.drop(columns=['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4'], inplace=True)
df.rename(columns={'v1': 'target', 'v2': 'text'}, inplace=True)

# Text Processing
nltk.download('punkt')
df['num_characters'] = df['text'].apply(len)
df['num_words'] = df['text'].apply(lambda x: len(nltk.word_tokenize(x)))
df['num_sentences'] = df['text'].apply(lambda x: len(nltk.sent_tokenize(x)))

# Create a LabelEncoder
encoder = LabelEncoder()

# Encode the 'target' column
df['target'] = encoder.fit_transform(df['target'])

# Display a sample of the DataFrame
print(df.sample(5))
print(df.info())

# Remove duplicates from the DataFrame
df = df.drop_duplicates(keep='first')
print(df.info())

# Specify custom colors for the pie chart
colorsin = ['lightblue', 'lightcoral']

# Create a pie chart with custom colors
plt.pie(df['target'].value_counts(), labels=['ham', 'spam'], autopct="%0.2f", colors=colorsin)
plt.show()

# Calculate the number of words
df['num_words'] = df['text'].apply(lambda x: len(nltk.word_tokenize(x)))
nltk.download('punkt')
df['num_sentences'] = df['text'].apply(lambda x: len(nltk.sent_tokenize(x)))

# Display descriptive statistics for 'ham'
ham_df = df[df['target'] == 0][['num_characters', 'num_words', 'num_sentences']].describe()
print("Descriptive statistics for 'ham':")
print(ham_df)

# Display descriptive statistics for 'spam'
spam_df = df[df['target'] == 1][['num_characters', 'num_words', 'num_sentences']].describe()
print("Descriptive statistics for 'spam':")
print(spam_df)

# Create and display histograms and pair plots
plt.figure(figsize=(12, 6))
sns.histplot(df[df['target'] == 0]['num_characters'])
sns.histplot(df[df['target'] == 1]['num_characters'], color='red')
plt.show()

plt.figure(figsize=(12, 6))
sns.histplot(df[df['target'] == 0]['num_words'])
sns.histplot(df[df['target'] == 1]['num_words'], color='red')
plt.show()

sns.pairplot(df, hue='target')
plt.show()

# # Display a correlation heatmap
# plt.figure(figsize=(8, 6))
# sns.heatmap(df.corr(), annot=True)
# plt.show()

# Ensure you've downloaded the NLTK stopwords data
nltk.download('stopwords')
def transform_text(text):
    text = text.lower()
    text = nltk.word_tokenize(text)
    
    y = []
    for i in text:
        if i.isalnum():
            y.append(i)
    
    # Reset 'y' here instead of clearing it
    text = y[:]
    
    y.clear()
    
    for i in text:
        if i not in stopwords.words('english') and i not in string.punctuation:
            y.append(i)
            
    text = y[:]
    y.clear()
    
    ps = PorterStemmer()
    for i in text:
        y.append(ps.stem(i))
             
    return " ".join(y)

# Apply the transform_text function to create the 'transformed_text' column
df['transformed_text'] = df['text'].apply(transform_text)


wc = WordCloud(width=500, height=500, min_font_size=10, background_color='white')
# Generate word cloud for spam messages
spam_wc = wc.generate(df[df['target'] == 1]['transformed_text'].str.cat(sep=" "))

# Display the spam word cloud
plt.figure(figsize=(15, 6))
plt.imshow(spam_wc)
plt.title("Spam Word Cloud")
plt.axis("off")
plt.show()

# Generate word cloud for ham messages
ham_wc = wc.generate(df[df['target'] == 0]['transformed_text'].str.cat(sep=" "))

# Display the ham word cloud
plt.figure(figsize=(15, 6))
plt.imshow(ham_wc)
plt.title("Ham Word Cloud")
plt.axis("off")
plt.show()

# Your DataFrame
print(df.head())

spam_corpus = df[df['target'] == 1]['transformed_text'].str.cat(sep=" ")

word_counter = Counter(spam_corpus)

most_common_words = word_counter.most_common(30)

word_freq_df = pd.DataFrame(most_common_words, columns=['Word', 'Frequency'])

plt.figure(figsize=(12, 6))
sns.barplot(x='Word', y='Frequency', data=word_freq_df)
plt.xticks(rotation=90)
plt.xlabel('Words')
plt.ylabel('Frequency')
plt.title('Top 30 Words in Spam Messages')
plt.show()

ham_corpus = []
for msg in df[df['target'] == 0]['transformed_text'].tolist():
    for word in msg.split():
        ham_corpus.append(word)

word_counter_ham = Counter(ham_corpus)

most_common_words_ham = word_counter_ham.most_common(30)

most_common_df_ham = pd.DataFrame(most_common_words_ham, columns=['Word', 'Count'])

plt.figure(figsize=(12, 6))
sns.barplot(data=most_common_df_ham, x='Word', y='Count')
plt.xticks(rotation='vertical')
plt.title("Top 30 Common Words in 'Ham' Messages")
plt.show()

print(df.head())

from sklearn.feature_extraction.text import CountVectorizer,TfidfVectorizer
cv = CountVectorizer()
tfidf = TfidfVectorizer(max_features=3000)
X = tfidf.fit_transform(df['transformed_text']).toarray()
print(X.shape)

y = df['target'].values

from sklearn.model_selection import train_test_split

X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=2)
from sklearn.naive_bayes import GaussianNB,MultinomialNB,BernoulliNB
from sklearn.metrics import accuracy_score,confusion_matrix,precision_score

gnb = GaussianNB()
mnb = MultinomialNB()
bnb = BernoulliNB()

gnb.fit(X_train,y_train)
y_pred1 = gnb.predict(X_test)
print(accuracy_score(y_test,y_pred1))
print(confusion_matrix(y_test,y_pred1))
print(precision_score(y_test,y_pred1))

mnb.fit(X_train,y_train)
y_pred2 = mnb.predict(X_test)
print(accuracy_score(y_test,y_pred2))
print(confusion_matrix(y_test,y_pred2))
print(precision_score(y_test,y_pred2))

bnb.fit(X_train,y_train)
y_pred3 = bnb.predict(X_test)
print(accuracy_score(y_test,y_pred3))
print(confusion_matrix(y_test,y_pred3))
print(precision_score(y_test,y_pred3))

from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score
from sklearn.naive_bayes import MultinomialNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import BaggingClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier

svc = SVC(kernel='sigmoid', gamma=1.0)
knc = KNeighborsClassifier()
mnb = MultinomialNB()
dtc = DecisionTreeClassifier(max_depth=5)
lrc = LogisticRegression(solver='liblinear', penalty='l1')
rfc = RandomForestClassifier(n_estimators=50, random_state=2)
abc = AdaBoostClassifier(n_estimators=50, random_state=2)
bc = BaggingClassifier(n_estimators=50, random_state=2)
etc = ExtraTreesClassifier(n_estimators=50, random_state=2)
gbdt = GradientBoostingClassifier(n_estimators=50,random_state=2)
xgb = XGBClassifier(n_estimators=50,random_state=2)
clfs = {
    'SVC' : svc,
    'KN' : knc, 
    'NB': mnb, 
    'DT': dtc, 
    'LR': lrc, 
    'RF': rfc, 
    'AdaBoost': abc, 
    'BgC': bc, 
    'ETC': etc,
    'GBDT':gbdt,
    'xgb':xgb
}
from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestClassifier

# Create an instance of the XGBoost classifier
clf_xgboost = XGBClassifier()

# Create an instance of the RandomForest classifier
clf_random_forest = RandomForestClassifier()

accuracy_scores = []
precision_scores = []

clfs = {
    'XGBoost': clf_xgboost,
    'RandomForest': clf_random_forest,
    # Add more classifiers as needed
}

def train_classifier(clf, X_train, y_train, X_test, y_test):
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    
    return accuracy, precision

for name, clf in clfs.items():
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    current_accuracy, current_precision = train_classifier(clf, X_train, y_train, X_test, y_test)
    print("For", name)
    print("Accuracy -", current_accuracy)
    print("Precision -", current_precision)
    accuracy_scores.append(current_accuracy)
    precision_scores.append(current_precision)

performance_df = pd.DataFrame({'Algorithm': clfs.keys(), 'Accuracy': accuracy_scores, 'Precision': precision_scores}).sort_values('Precision', ascending=False)
performance_df1 = pd.melt(performance_df, id_vars="Algorithm")

sns.catplot(x='Algorithm', y='value', hue='variable', data=performance_df1, kind='bar', height=5)
plt.ylim(0.5, 1.0)
plt.xticks(rotation='vertical')
plt.show()
